# Inventory — what the tenant layer and a seat consist of

Everything a build of the Property Insurance Claims solution binds and does not create, by scope. *How we create it* names the script in this pack or says *by hand*. Names in `code` are what the seed's `CONFIG.md` and the provided processes expect; change one and tell your coding agent to change it in `CONFIG.md` too.

## Organisation

| Name | What it is for | How we create it |
|---|---|---|
| Robot account `ClaimCaseRobot` (`ROBOT` in `pack.env`) | runs every serverless job: the six provided processes, the case, the Agents | by hand: Admin › Accounts › Robot accounts |
| External application, e.g. `Claim Case External App` | the identity the build's two web apps (the Action App of block 3d and the process app of block 6) sign in through | by hand: Admin › External Applications › Add, **non-confidential** (no secret) |
| — its user scopes | `DataFabric.Data.Read` `DataFabric.Schema.Read` `DataService.Data.Read` `DataService.Schema.Read` `OR.Buckets.Read` `OR.Execution.Read` `OR.Folders.Read` `OR.Jobs.Read` `OR.Tasks` `OR.Users.Read` `PIMS` | by hand, on the same application |
| — its redirect URLs | `http://localhost:5173` for local sign-in; `uip codedapp deploy` adds `https://<org>.uipath.host/<app>` per app | by hand for the first; deploy adds the rest |
| Its client id | ours is in the seed's `CONFIG.md`, **ours — replace** with yours | — |

## Tenant

| Name | What it is for | How we create it |
|---|---|---|
| Services | Orchestrator, Data Fabric, Integration Service, Maestro, Action Center, IXP (Document Understanding), Agents, Apps | by hand: Admin › Tenants › Services |
| Licences | Agent Units (one full build measured ~590 agent runs), AI Units (extraction), serverless runtime in Robot Units or Platform Units, whichever the tenant is metered in | by hand: Admin › Licenses |
| Robot tenant role | `Allow to be Automation User` — until it holds one, Orchestrator cannot see the robot and every folder grant fails | by hand: Orchestrator › Tenant › Manage access |
| Robot Data Service roles | `Data Service Data Reader` + `Data Service Data Writer` — the case and `Client Notification` write records as the robot; without them the job succeeds and nothing is written | by hand: Admin › tenant › Manage access |
| Your own roles | tenant `Allow to be Folder Administrator`, `Allow to be Automation User`, `Allow to be Automation Developer`, `Solutions Contributor`; Data Service Reader + Writer; IXP access. An org admin has these | by hand |
| Machine `Default Serverless` (`MACHINE`) | the serverless machine template every job folder needs | usually exists with the tenant; `prepare-tenant.sh` and `prepare-seat.sh` assign it |
| Entity `ClaimCorrespondence` | one row per letter sent to a claimant, written by `Client Notification`; the review app and block 4 read it | `prepare-tenant.sh` (schema in the script) |
| Entity `WorkshopFindings` (optional) | one row per finding the build agent logs with the seed's `log-finding.py` | `prepare-tenant.sh --findings` |
| IXP project `property-claims-<yours>`, tag `live` | the extraction model `Extract Claim Data (IXP)` calls; ours is named in `CONFIG.md`, **ours — replace** | by hand: `GUIDE.md` step 4 |

## Folder `Shared`

| Name | What it is for | How we create it |
|---|---|---|
| Folder `Shared` (`SHARED_FOLDER`) | holds what every seat shares | `prepare-tenant.sh` |
| Machine `Default Serverless` on it | | `prepare-tenant.sh` |
| You and the robot: `Automation User` | the build reads the connection id here; the case's first record write, as the robot, is refused 403 without it | `prepare-tenant.sh` |
| Connection `Shared Data Fabric Connection` (connector UiPath Data Fabric) | the case reads and writes the claim record through it | by hand: Integration Service › Connections, in `Shared`; interactive OAuth consent |

## Seat folder `ClaimCase-<seat>`

| Name | What it is for | How we create it |
|---|---|---|
| Folder `ClaimCase-<seat>` (`SEAT`, `FOLDER`) | everything the participant builds and runs | `prepare-seat.sh` |
| Process `Retrieve Property Claim` ← `propery-insurance-claims` | generates a claim and files its three documents in the buckets | `prepare-seat.sh` (package uploaded from `packages/`) |
| Process `Extract Claim Data (IXP)` ← `Extract.Claim.Data._IXP_` | runs the extraction model over the claim form. **Pinned to our IXP project** — `GUIDE.md` step 4 | `prepare-seat.sh` |
| Process `Retrieve Policy Document` ← `Retrieve.Policy.Document` | the policy document by policy number | `prepare-seat.sh` |
| Process `Retrieve Previous Claims` ← `Retrieve.Previous.Claims` | the claim history of a policy | `prepare-seat.sh` |
| Process `Retrieve Inspection Report` ← `Retrieve.Inspection.Report` | the assessor's report once it is filed | `prepare-seat.sh` |
| Process `Client Notification` ← `Client.Notification` | logs a letter to `ClaimCorrespondence`; sends no email | `prepare-seat.sh` |
| Buckets `Claims` · `Insurance Policies Repository` · `Assessor Reports` | where the generator files the documents | `prepare-seat.sh` |
| Machine `Default Serverless` | jobs in the folder | `prepare-seat.sh` |
| Owner: `Folder Administrator` + `Automation User` | the person who builds (`SEAT_OWNER`, else the logged-in user) | `prepare-seat.sh` |
| Robot: `Automation User` | without it every job fails 409 *Couldn't find any user with unattended robot permissions* | `prepare-seat.sh` |

The six processes' arguments and outputs are the seed's `contracts/provided-processes.md`.

## What the build creates itself

Not provided, listed so nothing here is mistaken for missing: the claim entity `ClaimCase_<seat>` (folder-scoped), the solution and deployment `ClaimCase-<seat>` with its folder `ClaimCase-<seat>-Deploy`, the Maestro case, seven Agents, the Coded Action App `claim-review-<seat>` and the process app `property-claims-<seat>`.

## Deliberately not provided

| | Why |
|---|---|
| an email connection | letters are logged to `ClaimCorrespondence`, never sent |
| a settlements or payment system | out of scope in the PDD; the case records the amount and stops |
