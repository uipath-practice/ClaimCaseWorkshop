#!/usr/bin/env bash
#
# One seat of the Property Insurance Claims exercise: folder, the six provided processes, buckets, machine, access.
# A copy of the script we run on our hosted tenant, with our specifics moved to ../pack.env and the packages read
# from ../packages. NOT tested on any other tenant: read it, run --dry-run first, let your coding agent fix the rest.
#
#   ./prepare-seat.sh --dry-run      show what would happen, change nothing
#   ./prepare-seat.sh                create the seat named in pack.env
#   ./prepare-seat.sh --repair       continue over a seat that already exists (a run that died half way)
#   ./prepare-seat.sh --smoke        then prove it: one generated claim, four files in three buckets
#
# Run prepare-tenant.sh first. A seat that already exists is an error unless --repair: on a shared tenant the
# likeliest reason is that it is somebody else's.

set -euo pipefail

DRY_RUN=false; REPAIR=false; SMOKE=false
for a in "$@"; do
  case "$a" in
    --dry-run) DRY_RUN=true ;;
    --repair)  REPAIR=true ;;
    --smoke)   SMOKE=true ;;
    -h|--help) sed -n '2,13p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *)         echo "unknown option: $a" >&2; exit 2 ;;
  esac
done

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ -f "$HERE/../pack.env" ]] || { echo "error: ../pack.env not found" >&2; exit 1; }
source "$HERE/../pack.env"
PACKAGES_DIR="$HERE/../packages"

# name|package id|description — the description is what a builder reads in Orchestrator. The version is the one
# in ../packages; the seed's contracts/provided-processes.md is the interface of each.
PROCESSES=(
  "Retrieve Property Claim|propery-insurance-claims|Receives a new property damage claim and files the claimant's documents."
  "Extract Claim Data (IXP)|Extract.Claim.Data._IXP_|Reads the claim submission form and returns the claim as structured data, with the policy number and the form itself."
  "Retrieve Policy Document|Retrieve.Policy.Document|Looks up an insurance policy by its number and returns the policy document."
  "Retrieve Previous Claims|Retrieve.Previous.Claims|Returns the claim history recorded against a policy."
  "Retrieve Inspection Report|Retrieve.Inspection.Report|Checks whether the independent assessor has filed a report for a claim, and returns it once they have."
  "Client Notification|Client.Notification|Sends correspondence to the claimant."
)
BUCKETS=("Claims" "Insurance Policies Repository" "Assessor Reports")

RED=$'\033[31m'; GREEN=$'\033[32m'; YELLOW=$'\033[33m'; DIM=$'\033[2m'; OFF=$'\033[0m'
step() { printf '\n%s==>%s %s\n' "$YELLOW" "$OFF" "$1"; }
ok()   { printf '    %s✓%s %s\n' "$GREEN" "$OFF" "$1"; }
skip() { printf '    %s·%s %s %s(already present)%s\n' "$DIM" "$OFF" "$1" "$DIM" "$OFF"; }
warn() { printf '    %s!%s %s\n' "$YELLOW" "$OFF" "$1"; }
die()  { printf '\n%serror:%s %s\n' "$RED" "$OFF" "$1" >&2; exit 1; }
would(){ printf '    %swould:%s %s\n' "$DIM" "$OFF" "$1"; }

# `uip` prints warnings to stderr and some calls merge them in with 2>&1, so parse from the first brace.
jqd() { python3 -c "
import json,sys
raw = sys.stdin.read()
i = raw.find('{')
d = json.loads(raw[i:]) if i >= 0 else {}
print($1)
" 2>/dev/null || true; }

# ------------------------------------------------------------------- preflight

[[ "$SEAT" =~ ^[A-Za-z0-9]{1,12}$ ]] || die "SEAT in pack.env must be 1-12 letters and digits, got '$SEAT'
      It becomes a folder, a package id, a Data Fabric entity (ClaimCase_<seat>) and an app name (lower case)."
$DRY_RUN && printf '%s(dry run — nothing will be created)%s\n' "$DIM" "$OFF"

step "Preflight"
STATUS_JSON=$(uip login status --output json 2>/dev/null) || die "not logged in — run 'uip login'"
[[ "$(echo "$STATUS_JSON" | jqd "d['Data']['Status']")" == "Logged in" ]] || die "not logged in — run 'uip login'"
LOGGED_ORG=$(echo "$STATUS_JSON" | jqd "d['Data']['Organization']")
LOGGED_TENANT=$(echo "$STATUS_JSON" | jqd "d['Data']['Tenant']")
ME=$(echo "$STATUS_JSON" | jqd "d['Data'].get('UserEmail','')")
[[ "$LOGGED_ORG" == "$ORG" && "$LOGGED_TENANT" == "$TENANT" ]] \
  || die "logged into $LOGGED_ORG/$LOGGED_TENANT, pack.env says $ORG/$TENANT — fix one of them"
OWNER="${SEAT_OWNER:-$ME}"
ok "logged in to $ORG/$TENANT as ${ME:-<unknown user>}; seat owner ${OWNER:-<none>}"

pkg_file() {   # $1 package id -> the .nupkg in ../packages
  ls "$PACKAGES_DIR/$1".[0-9]*.nupkg 2>/dev/null | head -1
}
pkg_version() {   # $1 .nupkg path -> its version, from the file name
  basename "$1" .nupkg | sed -E 's/^.*\.([0-9]+\.[0-9]+\.[0-9]+)$/\1/'
}
for entry in "${PROCESSES[@]}"; do
  REST="${entry#*|}"; PKG="${REST%%|*}"
  [[ -n "$(pkg_file "$PKG")" ]] || die "no $PKG.*.nupkg in $PACKAGES_DIR"
done
ok "six packages in ${PACKAGES_DIR##*/}/"

# --------------------------------------------------------------- 1. the folder

step "1/5  Folder $FOLDER"
# Case-insensitive: ClaimCase-jane and ClaimCase-Jane are one seat to a human and to the entity name that follows.
FOLDER_KEY=$(uip or folders list --all --output json 2>/dev/null | jqd "
next((f['Key'] for f in d.get('Data',[]) if (f.get('Name') or '').lower()=='$FOLDER'.lower()), '')")
if [[ -n "$FOLDER_KEY" ]] && ! $REPAIR && ! $DRY_RUN; then
  die "seat $FOLDER already exists — nothing has been changed. Pick another SEAT, or re-run with --repair to finish your own."
fi
if [[ -n "$FOLDER_KEY" ]]; then
  skip "$FOLDER"
elif $DRY_RUN; then
  would "create folder $FOLDER"
  FOLDER_KEY="<dry-run>"
else
  FOLDER_KEY=$(uip or folders create "$FOLDER" --description "Property Claims exercise — seat $SEAT" \
    --output json 2>&1 | jqd "d['Data']['Key']")
  [[ -n "$FOLDER_KEY" ]] || die "folder creation returned no key"
  ok "created $FOLDER"
fi

# -------------------------------------------------------- 2. packages in the feed

step "2/5  Packages in the tenant feed"
for entry in "${PROCESSES[@]}"; do
  REST="${entry#*|}"; PKG="${REST%%|*}"
  FILE=$(pkg_file "$PKG"); VER=$(pkg_version "$FILE")
  IN_FEED=$(uip or packages versions "$PKG" --output json 2>/dev/null | jqd "
'yes' if any(v.get('Version')=='$VER' for v in d.get('Data',[])) else ''")
  if [[ "$IN_FEED" == "yes" ]]; then
    skip "$PKG $VER"
  elif $DRY_RUN; then
    would "upload $(basename "$FILE")"
  else
    uip or packages upload "$FILE" --output json >/dev/null 2>&1 || die "upload failed for $(basename "$FILE")"
    ok "uploaded $PKG $VER"
  fi
done

# ------------------------------------------------------------ 3. the processes

# A process pins a package version and `processes update` cannot move it: a version change is delete + create.
# A Maestro case binds a process by name and folder, never by key, so the new process answers the old binding.
step "3/5  Processes in $FOLDER"
for entry in "${PROCESSES[@]}"; do
  NAME="${entry%%|*}"; REST="${entry#*|}"; PKG="${REST%%|*}"; DESC="${REST#*|}"
  VER=$(pkg_version "$(pkg_file "$PKG")")
  EXISTING=""
  [[ "$FOLDER_KEY" != "<dry-run>" ]] && EXISTING=$(uip or processes list --folder-key "$FOLDER_KEY" --output json 2>/dev/null | jqd "
next((p.get('Key','')+'|'+str(p.get('ProcessVersion','')) for p in d.get('Data',[]) if p.get('Name')=='$NAME'), '')")
  if [[ -n "$EXISTING" && "${EXISTING#*|}" == "$VER" ]]; then
    skip "$NAME at $VER"
  elif $DRY_RUN; then
    [[ -n "$EXISTING" ]] && would "move $NAME ${EXISTING#*|} → $VER (delete + create)" || would "create process '$NAME' from $PKG $VER"
  else
    if [[ -n "$EXISTING" ]]; then
      uip or processes delete "${EXISTING%%|*}" --yes --output json >/dev/null 2>&1 || die "could not delete process '$NAME'"
    fi
    uip or processes create --name "$NAME" --package-key "$PKG" --package-version "$VER" \
      --folder-key "$FOLDER_KEY" --description "$DESC" --output json >/dev/null 2>&1 || die "could not create process '$NAME'"
    ok "$NAME at $VER"
  fi
done

# -------------------------------------------------------------- 4. buckets and machine

step "4/5  Buckets and machine"
for B in "${BUCKETS[@]}"; do
  FOUND=""
  [[ "$FOLDER_KEY" != "<dry-run>" ]] && FOUND=$(uip or buckets list --folder-key "$FOLDER_KEY" --output json 2>/dev/null | jqd "
'yes' if any(b.get('Name')=='$B' for b in d.get('Data',[])) else ''")
  if [[ "$FOUND" == "yes" ]]; then skip "bucket $B"
  elif $DRY_RUN; then would "create bucket '$B'"
  else
    uip or buckets create "$B" --folder-key "$FOLDER_KEY" --description "Provided — the generator writes here." \
      --output json >/dev/null 2>&1 || die "bucket '$B' creation failed"
    ok "created bucket $B"
  fi
done

# A folder runs jobs only with a machine assigned; a fresh tenant does not assign the serverless one for you.
MACHINE_KEY=$(uip or machines list --limit 200 --output json 2>/dev/null | jqd "
next((m['Key'] for m in d.get('Data',[]) if m.get('Name')=='$MACHINE'), '')")
if [[ -z "$MACHINE_KEY" ]]; then
  warn "no machine named '$MACHINE' — jobs cannot run until one is assigned (set MACHINE in pack.env)"
elif $DRY_RUN; then
  would "assign machine '$MACHINE' to $FOLDER"
else
  uip or machines assign "$MACHINE_KEY" --folder-key "$FOLDER_KEY" --output json >/dev/null 2>&1 || true
  ASSIGNED=$(uip or machines list --folder-key "$FOLDER_KEY" --output json 2>/dev/null | jqd "
'yes' if any(m.get('Name')=='$MACHINE' for m in d.get('Data',[])) else ''")
  [[ "$ASSIGNED" == "yes" ]] && ok "machine $MACHINE" || warn "could not assign $MACHINE — assign it in the UI; jobs fail 409 until then"
fi

# --------------------------------------------------------------- 5. folder access

# A folder created by the API has no user, and a folder with no user has no unattended robot: `jobs start` fails
# 409 "Couldn't find any user with unattended robot permissions". `users assign` REPLACES a principal's roles in
# the folder, so never point this at a folder somebody configured by hand.
step "5/5  Folder access"
role_key() { uip or roles list --output json 2>/dev/null | jqd "next((r['Key'] for r in d.get('Data',[]) if r.get('Name')=='$1'), '')"; }
ROLE_ADMIN=$(role_key 'Folder Administrator'); ROLE_USER=$(role_key 'Automation User')
[[ -n "$ROLE_ADMIN" && -n "$ROLE_USER" ]] || die "folder roles 'Folder Administrator' / 'Automation User' not found in this tenant"
if $DRY_RUN; then
  would "grant ${OWNER:-<owner>} Folder Administrator + Automation User, robot $ROBOT Automation User"
else
  if [[ -n "$OWNER" ]] && uip or users import --username "$OWNER" --type DirectoryUser --folder-key "$FOLDER_KEY" \
       --role-keys "$ROLE_ADMIN,$ROLE_USER" --output json >/dev/null 2>&1; then
    ok "owner $OWNER (Folder Administrator + Automation User)"
  else
    warn "could not grant the owner ${OWNER:-<none>} — assign Folder Administrator + Automation User in the UI"
  fi
  # A robot account is visible to Orchestrator only once it holds a tenant role (prepare-tenant.sh, by hand).
  ROBOT_KEY=$(uip or users list --limit 200 --output json 2>/dev/null | jqd "
next((u['Key'] for u in d.get('Data',[]) if 'Robot' in str(u.get('Type')) and (u.get('UserName') or u.get('FullName') or '').lower()=='$ROBOT'.lower()), '')")
  if [[ -n "$ROBOT_KEY" ]] && uip or users assign --user-key "$ROBOT_KEY" --role-keys "$ROLE_USER" --folder-key "$FOLDER_KEY" \
       --output json >/dev/null 2>&1; then
    ok "robot $ROBOT (Automation User)"
  else
    warn "robot $ROBOT not granted — without it serverless jobs fail 409; assign Automation User in the UI"
  fi
fi

$DRY_RUN && { printf '\n%sdry run complete — nothing changed%s\n' "$DIM" "$OFF"; exit 0; }

# ------------------------------------------------------------------- smoke

# Counting processes proves they exist, not that the generator can run here and reach the buckets.
if $SMOKE; then
  step "Smoke — one generated claim"
  CLAIM="SMOKE-$SEAT-$(date +%H%M%S)"
  GEN_KEY=$(uip or processes list --folder-key "$FOLDER_KEY" --output json 2>/dev/null | jqd "
next((p['Key'] for p in d.get('Data',[]) if p.get('Name')=='Retrieve Property Claim'), '')")
  JOB=$(uip or jobs start "$GEN_KEY" --folder-key "$FOLDER_KEY" \
        --input-arguments "{\"in_ClaimID\":\"$CLAIM\",\"in_Scenario\":\"auto-settle\",\"in_Discrepancy\":\"\"}" \
        --output json 2>/dev/null | jqd "(d.get('Data') or {}).get('Jobs',[{}])[0].get('Key','')")
  [[ -n "$JOB" ]] || die "smoke: could not start Retrieve Property Claim"
  STATE=""
  for _ in $(seq 1 60); do
    STATE=$(uip or jobs list --folder-key "$FOLDER_KEY" --limit 20 --output json 2>/dev/null \
      | jqd "next((j.get('State','') for j in ((d.get('Data') or {}).get('Jobs') if isinstance(d.get('Data'),dict) else d.get('Data')) or [] if j.get('Key','').lower()=='$JOB'.lower()),'')")
    case "$STATE" in Successful|Faulted|Stopped) break ;; esac
    sleep 5
  done
  [[ "$STATE" == "Successful" ]] || die "smoke: the generator finished '$STATE' — usually the robot grant or the machine"
  ok "generator ran; $CLAIM-claim.pdf and .json are in Claims, the incident report in Assessor Reports"
  printf '    %sthese are also your first IXP training samples (GUIDE.md step 4)%s\n' "$DIM" "$OFF"
fi

cat <<SUMMARY

${GREEN}Seat $SEAT ready.${OFF}

  Folder      $FOLDER  ($FOLDER_KEY)
  Processes   ${#PROCESSES[@]}, at the versions in ../packages
  Buckets     ${BUCKETS[*]}

Before the build: Extract Claim Data (IXP) is pinned to OUR IXP project and cannot read yours — GUIDE.md step 4.
SUMMARY
