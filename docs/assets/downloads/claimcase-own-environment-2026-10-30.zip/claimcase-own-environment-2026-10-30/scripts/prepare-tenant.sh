#!/usr/bin/env bash
#
# The tenant layer of the Property Insurance Claims exercise, once per tenant, before the first seat.
# A copy of the script we run on our hosted tenant, with our specifics moved to ../pack.env. NOT tested
# on any other tenant: read it, run --dry-run first, and let your coding agent fix what your tenant needs.
#
#   ./prepare-tenant.sh --dry-run          show what would happen, change nothing
#   ./prepare-tenant.sh                    ClaimCorrespondence entity, Shared folder, machine, folder roles
#   ./prepare-tenant.sh --findings         also the WorkshopFindings entity (the seed's log-finding.py writes there)
#
# Idempotent: every step checks first, so re-running is the way to repair a half-prepared tenant.
# By hand, because none has a CLI path (the script prints them at the end): the robot account and its tenant
# role, the Shared Data Fabric Connection (OAuth consent), the external application, the IXP project.

set -euo pipefail

DRY_RUN=false; FINDINGS=false
for a in "$@"; do
  case "$a" in
    --dry-run)  DRY_RUN=true ;;
    --findings) FINDINGS=true ;;
    -h|--help)  sed -n '2,14p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *)          echo "unknown option: $a" >&2; exit 2 ;;
  esac
done

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ -f "$HERE/../pack.env" ]] || { echo "error: ../pack.env not found" >&2; exit 1; }
source "$HERE/../pack.env"

GREEN=$'\033[32m'; RED=$'\033[31m'; YELLOW=$'\033[33m'; DIM=$'\033[2m'; OFF=$'\033[0m'
step() { printf '\n%s==>%s %s\n' "$YELLOW" "$OFF" "$1"; }
ok()   { printf '    %s✓%s %s\n' "$GREEN" "$OFF" "$1"; }
skip() { printf '    %s·%s %s %s(already present)%s\n' "$DIM" "$OFF" "$1" "$DIM" "$OFF"; }
warn() { printf '    %s!%s %s\n' "$YELLOW" "$OFF" "$1"; }
die()  { printf '\n%serror:%s %s\n' "$RED" "$OFF" "$1" >&2; exit 1; }
would(){ printf '    %swould:%s %s\n' "$DIM" "$OFF" "$1"; }
jqd() { python3 -c "
import json,sys
raw = sys.stdin.read()
i = raw.find('{')
d = json.loads(raw[i:]) if i >= 0 else {}
print($1)
" 2>/dev/null || true; }

TMPDIR_T=$(mktemp -d)
trap 'rm -rf "$TMPDIR_T"' EXIT
$DRY_RUN && printf '%s(dry run — nothing will be created)%s\n' "$DIM" "$OFF"

step "Preflight"
STATUS_JSON=$(uip login status --output json 2>/dev/null) || die "not logged in — run 'uip login'"
[[ "$(echo "$STATUS_JSON" | jqd "d['Data']['Status']")" == "Logged in" ]] || die "not logged in — run 'uip login'"
LOGGED_ORG=$(echo "$STATUS_JSON" | jqd "d['Data']['Organization']")
LOGGED_TENANT=$(echo "$STATUS_JSON" | jqd "d['Data']['Tenant']")
ME=$(echo "$STATUS_JSON" | jqd "d['Data'].get('UserEmail','')")
[[ "$LOGGED_ORG" == "$ORG" && "$LOGGED_TENANT" == "$TENANT" ]] \
  || die "logged into $LOGGED_ORG/$LOGGED_TENANT, pack.env says $ORG/$TENANT — fix one of them"
ok "logged in to $ORG/$TENANT as ${ME:-<unknown user>}"

# ------------------------------------------------------ tenant-level entities

# Declared schemas, reconciled on every run: create if missing, add missing
# columns, widen a column narrower than declared, never narrow, never remove.
# A text column created without an explicit lengthLimit gets the 200-character
# default, which refuses every longer value. The reconcile compares by name
# against `Fields[].Name`.
ensure_entity() {   # $1 name, $2 display name, $3 description, $4 schema JSON (array of fields)
  local NAME="$1" DISPLAY="$2" DESC="$3" SCHEMA="$4" EXISTING NEW REPAIR NOTES LEFT COUNT
  COUNT=$(printf '%s' "$SCHEMA" | python3 -c 'import json,sys; print(len(json.load(sys.stdin)))')
  step "Entity $NAME"
  EXISTING=$(uip df entities list --output json 2>/dev/null | python3 -c "
import json,sys
for e in json.load(sys.stdin).get('Data',[]):
    if e.get('Name')=='$NAME': print(e.get('Id')); break
")
  if [[ -z "$EXISTING" ]]; then
    if $DRY_RUN; then
      printf '    %swould:%s create %s with %s columns\n' "$DIM" "$OFF" "$NAME" "$COUNT"
      return 0
    fi
    printf '{"displayName":"%s","description":"%s","fields":%s}' "$DISPLAY" "$DESC" "$SCHEMA" > "$TMPDIR_T/create-$NAME.json"
    NEW=$(uip df entities create "$NAME" --file "$TMPDIR_T/create-$NAME.json" --output json 2>&1 | python3 -c "
import json,sys
raw = sys.stdin.read()          # a CLI warning on stderr must not break the parse
i = raw.find('{')
try: print(json.loads(raw[i:])['Data']['Id'])
except Exception: pass
")
    [[ -n "$NEW" ]] || die "could not create $NAME"
    ok "created $NAME"
    printf '      %sid %s%s\n' "$DIM" "$NEW" "$OFF"
    EXISTING="$NEW"
  else
    skip "$NAME"
    printf '      %sid %s%s\n' "$DIM" "$EXISTING" "$OFF"
  fi

  # ---- reconcile: add what is missing, widen what is too narrow, touch nothing else
  REPAIR=$(uip df entities get "$EXISTING" --output json 2>/dev/null | SCHEMA="$SCHEMA" python3 -c "
import json, os, sys
want = {f['name']: f for f in json.loads(os.environ['SCHEMA'])}
have = {}
for f in (json.load(sys.stdin).get('Data') or {}).get('Fields') or []:
    have[f['Name']] = f
add, upd, notes = [], [], []
for name, w in want.items():
    h = have.get(name)
    if h is None:
        add.append(w); notes.append('add ' + name)
        continue
    lim = (h.get('FieldDataType') or {}).get('LengthLimit') or 0
    if w.get('lengthLimit') and lim and lim < w['lengthLimit']:
        upd.append({'id': h['Id'], 'lengthLimit': w['lengthLimit']})
        notes.append('widen %s %d -> %d' % (name, lim, w['lengthLimit']))
body = {}
if add: body['addFields'] = add
if upd: body['updateFields'] = upd
print(json.dumps({'body': body, 'notes': notes}))
")
  NOTES=$(printf '%s' "$REPAIR" | python3 -c "import json,sys; print('; '.join(json.load(sys.stdin)['notes']))")
  if [[ -z "$NOTES" ]]; then
    ok "schema matches — $COUNT columns"
  elif $DRY_RUN; then
    printf '    %swould:%s %s\n' "$DIM" "$OFF" "$NOTES"
  else
    printf '%s' "$REPAIR" | python3 -c "import json,sys; print(json.dumps(json.load(sys.stdin)['body']))" > "$TMPDIR_T/repair-$NAME.json"
    uip df entities update "$EXISTING" --file "$TMPDIR_T/repair-$NAME.json" --output json >/dev/null 2>&1 \
      || die "could not reconcile $NAME schema ($NOTES)"
    # updateFields can return Success and silently ignore a change, so read it back.
    LEFT=$(uip df entities get "$EXISTING" --output json 2>/dev/null | SCHEMA="$SCHEMA" python3 -c "
import json, os, sys
want = {f['name']: f for f in json.loads(os.environ['SCHEMA'])}
have = {f['Name']: f for f in (json.load(sys.stdin).get('Data') or {}).get('Fields') or []}
bad = [n for n, w in want.items()
       if n not in have or (w.get('lengthLimit') and ((have[n].get('FieldDataType') or {}).get('LengthLimit') or 0)
                            and (have[n]['FieldDataType']['LengthLimit'] < w['lengthLimit']))]
print(', '.join(bad))
")
    [[ -z "$LEFT" ]] || die "the platform accepted the schema change but did not apply it to: $LEFT"
    ok "schema reconciled — $NOTES"
  fi
}

# The findings table, optional (--findings). The seed's log-finding.py writes one
# row per finding a build agent records; without the table the script keeps the
# finding in the build's PROGRESS.md only.
read -r -d '' FINDINGS_SCHEMA <<'JSON' || true
[
 {"name":"seat","type":"STRING","lengthLimit":200,"description":"Which seat wrote this"},
 {"name":"block","type":"STRING","lengthLimit":200,"description":"Which block it came out of, e.g. 3d-case"},
 {"name":"codingAgent","type":"STRING","lengthLimit":200,"description":"Which coding agent"},
 {"name":"model","type":"STRING","lengthLimit":200,"description":"Which model"},
 {"name":"effort","type":"STRING","lengthLimit":200,"description":"Reasoning or effort tier it ran at"},
 {"name":"uipVersion","type":"STRING","lengthLimit":200,"description":"uip CLI version"},
 {"name":"skillsVersion","type":"STRING","lengthLimit":200,"description":"uipath-* skills bundle version"},
 {"name":"osShell","type":"STRING","lengthLimit":200,"description":"Operating system and shell the seat ran on"},
 {"name":"seedVersion","type":"STRING","lengthLimit":200,"description":"Seed date and commit"},
 {"name":"category","type":"STRING","lengthLimit":200,"description":"Free text: seed-gap, platform-bug, friction, redundancy, ..."},
 {"name":"source","type":"STRING","lengthLimit":200,"description":"Where the answer came from: seed | skill | cli-help | docs | model | trial-error"},
 {"name":"ask","type":"STRING","lengthLimit":200,"description":"What should change: keep | cut | fix | add | move | none"},
 {"name":"artifact","type":"STRING","lengthLimit":400,"description":"Which seed file and section"},
 {"name":"summary","type":"MULTILINE_TEXT","lengthLimit":10000,"description":"What happened, what was tried, what happened next"},
 {"name":"evidence","type":"MULTILINE_TEXT","lengthLimit":10000,"description":"Verbatim error, the command that produced it, or the few lines that show it"},
 {"name":"processed","type":"BOOLEAN","description":"Set once a maintainer has folded this into the seed"}
]
JSON
$FINDINGS && ensure_entity "WorkshopFindings" "Workshop Findings" \
  "One row per finding, written by participants build agents as they work." "$FINDINGS_SCHEMA"

# The correspondence table, required. Every letter a seat's build sends to a
# claimant lands here, written by the provided `Client Notification` automation:
# the thread the review app shows, and what 4-verify reads the letter from.
# Tenant-level; nothing here removes rows.
read -r -d '' CORRESPONDENCE_SCHEMA <<'JSON' || true
[
 {"name":"seat","type":"STRING","lengthLimit":200,"description":"The seat whose build sent this letter (ClaimCase-<seat>)"},
 {"name":"claimId","type":"STRING","lengthLimit":100,"description":"The claim reference the letter is about (PCL-...)"},
 {"name":"stage","type":"STRING","lengthLimit":100,"description":"screening | settlement | review — or empty when the caller did not say"},
 {"name":"sentAt","type":"DATETIME_WITH_TZ","description":"When the automation logged it"},
 {"name":"recipient","type":"STRING","lengthLimit":200,"description":"The address the letter was addressed to"},
 {"name":"subject","type":"STRING","lengthLimit":500,"description":"Subject line"},
 {"name":"body","type":"MULTILINE_TEXT","lengthLimit":10000,"description":"The letter as sent"},
 {"name":"jobKey","type":"STRING","lengthLimit":100,"description":"The automation's job key, for tracing"},
 {"name":"folderKey","type":"STRING","lengthLimit":100,"description":"The folder the job ran in"}
]
JSON
ensure_entity "ClaimCorrespondence" "Claim Correspondence" \
  "One row per letter sent to a claimant, written by Client Notification. Permanent: the record that a seat completed the exercise." "$CORRESPONDENCE_SCHEMA"

# ------------------------------------------------------ the Shared folder

# Holds the one Data Fabric connection every seat's case reads. You and the robot need Automation User
# here (Connections.View): without it the build cannot read the connection id, and the case's first
# record write, which runs as the robot, is refused 403.
step "Folder $SHARED_FOLDER"
SHARED_KEY=$(uip or folders list --all --output json 2>/dev/null | jqd "
next((f['Key'] for f in d.get('Data',[]) if (f.get('Name') or '').lower()=='$SHARED_FOLDER'.lower()), '')")
if [[ -n "$SHARED_KEY" ]]; then
  skip "$SHARED_FOLDER"
elif $DRY_RUN; then
  would "create folder $SHARED_FOLDER"
else
  SHARED_KEY=$(uip or folders create "$SHARED_FOLDER" --description "Shared by every ClaimCase seat: the Data Fabric connection" \
    --output json 2>&1 | jqd "d['Data']['Key']")
  [[ -n "$SHARED_KEY" ]] || die "folder creation returned no key"
  ok "created $SHARED_FOLDER"
fi

step "Machine $MACHINE on $SHARED_FOLDER"
MACHINE_KEY=$(uip or machines list --limit 200 --output json 2>/dev/null | jqd "
next((m['Key'] for m in d.get('Data',[]) if m.get('Name')=='$MACHINE'), '')")
if [[ -z "$MACHINE_KEY" ]]; then
  warn "no machine named '$MACHINE' — create a serverless machine template (Orchestrator > Tenant > Machines) and set MACHINE in pack.env"
elif $DRY_RUN || [[ -z "$SHARED_KEY" ]]; then
  would "assign $MACHINE to $SHARED_FOLDER"
else
  uip or machines assign "$MACHINE_KEY" --folder-key "$SHARED_KEY" --output json >/dev/null 2>&1 || true
  ok "$MACHINE assigned (or already was)"
fi

step "Folder roles on $SHARED_FOLDER"
ROLE_USER=$(uip or roles list --output json 2>/dev/null | jqd "
next((r['Key'] for r in d.get('Data',[]) if r.get('Name')=='Automation User'), '')")
[[ -n "$ROLE_USER" ]] || die "folder role 'Automation User' not found in this tenant"
OWNER="${SEAT_OWNER:-$ME}"
if $DRY_RUN || [[ -z "$SHARED_KEY" ]]; then
  would "grant Automation User to $OWNER and to robot $ROBOT"
else
  if uip or users import --username "$OWNER" --type DirectoryUser --folder-key "$SHARED_KEY" --role-keys "$ROLE_USER" --output json >/dev/null 2>&1; then
    ok "$OWNER (Automation User)"
  else
    warn "could not grant $OWNER — assign Automation User in the UI"
  fi
  # A robot account is visible to Orchestrator only once it holds a tenant role (see the by-hand list below).
  ROBOT_KEY=$(uip or users list --limit 200 --output json 2>/dev/null | jqd "
next((u['Key'] for u in d.get('Data',[]) if 'Robot' in str(u.get('Type')) and (u.get('UserName') or u.get('FullName') or '').lower()=='$ROBOT'.lower()), '')")
  if [[ -n "$ROBOT_KEY" ]] && uip or users assign --user-key "$ROBOT_KEY" --role-keys "$ROLE_USER" --folder-key "$SHARED_KEY" --output json >/dev/null 2>&1; then
    ok "robot $ROBOT (Automation User)"
  else
    warn "robot $ROBOT is not visible to Orchestrator yet — give it the tenant role below, then re-run"
  fi
fi

# ------------------------------------------------------ by hand

step "By hand, once (no CLI path) — see ../inventory.md"
cat <<EOF
    · robot account $ROBOT: Admin > Accounts > Robot accounts; then tenant role 'Allow to be Automation User'
      (Orchestrator > Tenant > Manage access) and Data Service Data Reader + Writer (Admin > tenant > Manage access)
    · connection 'Shared Data Fabric Connection' (connector: UiPath Data Fabric) in folder $SHARED_FOLDER —
      Integration Service > Connections, interactive OAuth consent
    · an external application, non-confidential, user scopes and redirect as in ../inventory.md
    · your IXP project, trained on generator samples — ../GUIDE.md step 4
EOF

printf '\n%sTenant layer done.%s Now scripts/prepare-seat.sh.\n' "$GREEN" "$OFF"
