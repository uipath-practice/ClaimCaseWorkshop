# Building the Property Insurance Claims solution in your own environment

The ClaimCase workshop runs on a tenant we host, where every seat is prepared before the participant arrives. This pack is for building the same solution in your own organisation and tenant. It is a checklist of what must exist before block 1, not a procedure: **these steps and scripts were written against our hosted tenant and have not been tested anywhere else.** Expect to solve a few technical difficulties with your coding agent, and tell us what was missing.

| In this pack | |
|---|---|
| `packages/` | the six provided processes as `.nupkg`, at the versions our tenant runs |
| `ixp/taxonomy.json` | the extraction model's taxonomy, to import into your own IXP project |
| `pack.env` | your organisation, tenant, seat, folder and robot names; both scripts read it |
| `scripts/prepare-tenant.sh` | the tenant layer, once: entities, the `Shared` folder, its machine and roles |
| `scripts/prepare-seat.sh` | one seat: folder, the six processes, buckets, machine, access |
| `inventory.md` | everything the tenant layer and a seat consist of, by scope, and how each is made |

Both scripts take `--dry-run`; run it first. They need `bash`, `python3` and `uip`, logged in to your tenant (`uip login status`).

## The checklist

- [ ] **1. You build in your own tenant and organisation.** The seed's `CONFIG.md` names ours: the organisation, the tenant, the IXP project, the external application's client id and scopes, and "you share this tenant". Before block 1, give your coding agent this prompt: *"You are building in organisation `<org>`, tenant `<tenant>`, seat folder `ClaimCase-<seat>`. Review and update every setting in CONFIG.md that names another organisation, tenant, IXP project or external application, using inventory.md from the own-environment pack."*
- [ ] **2. Licences and services.** The tenant has Orchestrator, Data Fabric, Integration Service, Maestro, Action Center, IXP, Agents and Apps enabled. It holds Agent Units (one full build measured ~590 agent runs), AI Units for extraction, and a serverless runtime budget in Robot Units or Platform Units, whichever it is metered in. You have org-admin rights (for the external application and the robot account), and `uip` is installed and logged in.
- [ ] **3. The tenant layer, once.** Edit `pack.env`, then `scripts/prepare-tenant.sh` creates the `ClaimCorrespondence` entity (`--findings` adds `WorkshopFindings`), the `Shared` folder with the serverless machine, and *Automation User* there for you and the robot. By hand, because none has a CLI path: the robot account with the tenant role *Allow to be Automation User* plus *Data Service Data Reader* and *Writer*; the `Shared Data Fabric Connection` in `Shared` (Integration Service, OAuth consent); an external application, non-confidential, with the user scopes in `inventory.md` and the redirect `http://localhost:5173`.
- [ ] **4. The IXP project: you create and label it yourself.** Create an IXP project (`property-claims-<yours>`) and import `ixp/taxonomy.json`. Prepare the seat (step 5), then have your coding agent run `Retrieve Property Claim` a few dozen times and upload the claim forms it drops in the `Claims` bucket as training documents; label them, train, and publish with the tag `live`. **Known difficulty:** the provided `Extract Claim Data (IXP)` pins our project id, tag and version literally, inside the compiled package, so it cannot read your project. Have your coding agent build a replacement process of the same name in your seat, with the same arguments and outputs (the seed's `contracts/provided-processes.md`), against your project.
- [ ] **5. The seat.** `scripts/prepare-seat.sh` (add `--smoke` to generate one real claim) creates the folder `ClaimCase-<seat>` (edit `pack.env` for another name), uploads the six packages to the tenant feed and creates them as processes, creates the buckets `Claims` · `Insurance Policies Repository` · `Assessor Reports`, assigns the serverless machine, and grants *Folder Administrator* + *Automation User* to you and *Automation User* to the robot.
- [ ] **6. Then build as everyone else does.** Clone the [seed](https://github.com/uipath-practice/PropertyClaimsSeeds) and follow the [handbook](https://uipath-practice.github.io/ClaimCaseWorkshop/) from *Prepare › 3. Get the seed*, with step 1's prompt before block 1.

These steps were written against our hosted tenant and are not tested elsewhere. Tell us what was missing.
